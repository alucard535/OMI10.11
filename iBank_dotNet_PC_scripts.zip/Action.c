Action()
{

	lr_start_transaction("iBank_NET_001_HomePage");
/*Correlation comment - Do not change!  Original value='/wEPDwUKLTg0NjY3NzMwMmQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgIFEUxvZ2luMSRSZW1lbWJlck1lBRdMb2dpbjEkTG9naW5JbWFnZUJ1dHRvbvrk2f08gx5rkjlyCyP2DDa9vHd/nfw0IGSarbmlHjMc' Name ='__VIEWSTATE' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=__VIEWSTATE",
		"RegExp=id=\"__VIEWSTATE\"\\ value=\"(.*?)\"\\ ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/Login.aspx*",
		LAST);

	web_url("Login.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Login.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		//"Url=../iBank_Investor_deploy/WebResource.axd?d=CxFd1bYQ6iJbePSyXKfsUdkmk6L9dVUAJU0ukZXWGAnjSOuzog1UPQ83x-49Z_Rnyke5bS_TbnF0h9eTrG3O2-aQL_ArnxyRypfvEJyedOA1&t=634773866700000000", ENDITEM, 
		//"Url=../iBank_Investor_deploy/WebResource.axd?d=Zbl-jgV-pMt7vYhuvzCnSLdhvUFTOYjuu7oQJZulP8zMc_5v80tskomv6wE-PM_34Eb3_FaY93IJ_n0iHVsjWXARpsrkD4XS1c8NG_AWv5U1&t=634773866700000000", ENDITEM, 
		//"Url=Images/name2.JPG", ENDITEM, 
		//"Url=Images/image1.jpg", ENDITEM, 
		//"Url=Images/imagesCAHR3VEG.jpg", ENDITEM, 
		//"Url=Images/imagesCAM9KF7G.jpg", ENDITEM, 
		//"Url=Images/tradetips.JPG", ENDITEM, 
		LAST);
	lr_end_transaction("iBank_NET_001_HomePage",LR_AUTO);
	
	lr_think_time(2);
	
	lr_start_transaction("iBank_NET_002_Login");

	web_submit_data("Login.aspx_2", 
		"Action=http://10.10.3.155/iBank_investor_deploy/Login.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwUKLTg0NjY3NzMwMmQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgIFEUxvZ2luMSRSZW1lbWJlck1lBRdMb2dpbjEkTG9naW5JbWFnZUJ1dHRvbqxuHkA0SqrGRIbaOtKnjXohCY+cUXcuwgXUnqLGAPTK", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAVgL5yKFvvhRcZ/9HC30pFA8x5TPe4Fb2SCxWQFXQqD6Fz4Ff/mRdr9eJovHJ26GXDR0dl5Dt4O7K+LnH/gkYIQ0LfbvGI/Wk1EnCpPRzC0avnR/tCWFRKkYQUCm8xllbZdhj5I6MTYDYJKxV2tnOu9", ENDITEM, 
		"Name=Login1$UserName", "Value=AJ9902", ENDITEM, 
		"Name=Login1$Password", "Value=Passw0rd", ENDITEM, 
		"Name=Login1$LoginButton", "Value=Log In", ENDITEM, 
		EXTRARES, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=TMhzDgiMDwJGLjrgb6p4TkeT4piWbgmmSMzC08QJ61ypY_D1ZCq7v7HzAnDBtLdKzExpTDw6cP8CLUh5iDY6WHdwpmMjtZumyIsxj-0VIrxSwy6e6wypS-53nDzWkDLigdTo0SBTdGz3CTZdMQKVkHw5SvrPHyLatMZTPNltWKcRILZjP593am-Z5RAWsXCl0&t=ca758f3", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=HgRNj4-meR6i77HdEZnFDZWME2sbwSymFlrp_X6cA4vkMujKes-q4-roRpUpJIqrJWFhWtIlTCXGJukrgn3MkBI0vd2UzcrKBKo4JkYHwmHmliy0NJdg5Ol205ZYtmv9L6mwE4Osjd1zic9QwYa9RQ2&t=2e8dfcac", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=ai3ijKGGLM5r5HhCRV9rkbp1T6eoWysC4Jg5Xheh1Bx0WF-7raWiIfrWC7xMKt8urST-0SrxQQ8Of1sgKozPogcK61twxSrsNFGlmL4Zsz6AVMcIYcWXdY5GBPmWagWmqUpp0cA533lUKBkuGtdUpru6SfxasOeUCJRfwMIv_dTfZYXrUoq3qYIr-IHKgOiu0&t=ca758f3", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=ZWtbd_2OO7eCvjnXD7wANYU6_MXJH_rrGnL_UrTzbOuezDZvI66LtC_XEWr6fTZzkW3DRRV_9VwIzoCnmw7u2ylTP1XOUPClXwoQOy9z09rt8duczP87_ugp9txb1kdkd42lotNon7fkX12zq4pJylvQfoDG5dsdPBALwwAzoUicT-KOaDSIcQpap8c4JaOe0&t=ca758f3", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=EsVtmB6vYK_68nJCPP8GiYF3clYqQ9rxou2kluAigHa_AOS61isbIkDuSEdpWzDkBalqkAC7ZC_dvl93j4lJHh6_pork66CDy9xAPSXxgnU1&t=635145251460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/poll.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/up.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/banner112.jpg", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/buySell.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		LAST);


	lr_end_transaction("iBank_NET_002_Login",LR_AUTO);
	
	lr_think_time(2);
	
	lr_start_transaction("iBank_NET_004_Portfolio");

	web_url("Portfolio.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Portfolio.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Trading.aspx", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("iBank_NET_004_Portfolio",LR_AUTO);
	lr_think_time(2);
	lr_start_transaction("iBank_NET_005_Accounts");
	
	web_url("Accounts.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Accounts.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Portfolio.aspx", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("iBank_NET_005_Accounts",LR_AUTO);
	lr_think_time(2);
	
	lr_start_transaction("iBank_NET_999_Logout");

	web_url("Logout.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Logout.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Accounts.aspx", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);
	lr_end_transaction("iBank_NET_999_Logout",LR_AUTO);

	return 0;
}