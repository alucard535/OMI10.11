Action()
{

lr_start_transaction("iBank_NET_001_HomePage");

	web_url("Home.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Home.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=BxlGf4AXK3gGaC0jrvd5liEMq6fFNPJ3lAAozgY-BC2tA_rtEqrQWJOpXbGAtfSKBDfd8tIecTBgGqpvwIfpvnh88vQq69CV4T0JmxG3J5A1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=-zB6828wYI1dChaSKumS2PFmSzA2xP9PGL0_G1OqBM09305dfJsdqmnNdvkvc1Hj282OBi8bxb1ky1nWo-8qn91mS4-qmQWQgi3QLCk7RLw1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/name2.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/image1.jpg", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/imagesCAM9KF7G.jpg", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/imagesCAHR3VEG.jpg", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/tradetips.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_save_string(lr_decrypt("574ee60c76e492ab9a1b9ac8"), "PasswordParameter");
	
	
lr_end_transaction("iBank_NET_001_HomePage", LR_AUTO);

lr_start_transaction("iBank_NET_002_Login");

	web_custom_request("Login.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Login.aspx", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=%2FwEPDwUKLTg0NjY3NzMwMmQYAQUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgIFEUxvZ2luMSRSZW1lbWJlck1lBRdMb2dpbjEkTG9naW5JbWFnZUJ1dHRvbl8TTVA0K4FI994JPSquf6hYk1oCIHVe995Iu4kw6UBL&__VIEWSTATEGENERATOR=D0D8CD93&__EVENTVALIDATION=%2FwEdAAW7L3CPPqHrli4i18wFS26G8x5TPe4Fb2SCxWQFXQqD6Fz4Ff%2FmRdr9eJovHJ26GXDR0dl5Dt4O7K%2BLnH%2FgkYIQ0LfbvGI%2FWk1EnCpPRzC0arsPJcconun74wOgpzhpRtcYZJB8jYHnzUdGzhdbzNqd&Login1%24UserName=AJ9902&Login1%24Password={PasswordParameter}&"
		"Login1%24LoginButton=Log+In", 
		EXTRARES, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=BxlGf4AXK3gGaC0jrvd5liEMq6fFNPJ3lAAozgY-BC2tA_rtEqrQWJOpXbGAtfSKBDfd8tIecTBgGqpvwIfpvnh88vQq69CV4T0JmxG3J5A1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=-oxN7qCMtcOxub6C3XfChlqzy5SR5yfIn1euYjEdEWIfW4RkT5e5gEhxBO411Hlnn6GMcAfOf8wBYYjrLmQ_ArnAE4Mpx786ZiQ5dyfOxa7-k7hVwpTGTuzawe2gyyLJHuzyH_rgUWxzq-zF5xPPQ_hHt_s58IfTSJfXCcm8iariADirxzug86baSo4Ic1qi0&t=ffffffffcc58dd65", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=Ew1Vj9TZRQHg_fldiHYtE6mwLj-pXP0wCnrM0WaP6zVMbo2TbcA64sjkws7qSfTQgCWO_PereysjcPxwWeEL8LGiHI9HEkx7WgjHohl0OpisuyPH0anmLl--DoX2HtsNRnfItAHgHQ7D0wr5C1fXXg2&t=36fde08a", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=CvxhkvAH3cnFbtHtX1z1yh8gK-7VYUthonFxO6HhYQBfTOF406fRuhSWsFTfHH-jqGZydOg7kKV2Gp48sQUNTJxjCDYCSWcU-el4c_8_aovWRJ7aOjNjHIYkkpfQLyPFGkpcGs9F1j3MnB_VubVM4bZhzMYUOOXzmuA7b0vpVKGue4FLW8OQXsmZFqEboHrY0&t=ffffffffcc58dd65", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=MJJDHH-k-sR8F2qWFBYVHZNNQOdSQCJ1SW_6aVCn_9d_h18l8m5OPd2pZapHaZXNBYlUBAZR60XhRrRAAe2vSX64Fov4hqIsnCfD7QY8QiU7iFxAjs3XNoiFuYgNI_o0RKX82B4QO8UW47Rv3sNuAWCSnQLWXNQAWI8npewxF8ht7Dv2_XlOfajf4BiMG-ra0&t=ffffffffcc58dd65", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/up.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/poll.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/buySell.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=i4ctsPxkLc9nsII7kqSUvEIrV0XniFFT9Ct2SuhJXGB7KKYTrBn8B7KocNaKdOpGvPhFbTNF50GiybelaQMAherb0arcLYQ_JP4oi_mupxI1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=Images/banner112.jpg", "Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", ENDITEM, 
		"Url=../favicon.ico", "Referer=", ENDITEM, 
		"Url=https://ieonline.microsoft.com/iedomainsuggestions/ie11/suggestions.en-US", "Referer=", ENDITEM, 
		LAST);

	web_submit_data("Home.aspx_2", 
		"Action=http://10.10.3.155/iBank_investor_deploy/Home.aspx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ctl00$ScriptManager1", "Value=ctl00$ScriptManager1|ctl00$Timer1", ENDITEM, 
		"Name=__EVENTTARGET", "Value=ctl00$Timer1", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwULLTE5MjM3MTA3MDUPZBYCZg9kFgICAw9kFgICCQ8PFgIeBFRleHQFA0FteWRkZNcbrXssUatf8XeAYdwC3GJikOHP9foNrlBSKhg70/Cf", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=9AF846BE", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAbGoIx1NUIs8myhD625+rjI3IoTh/glSZuXftLnCL75vaL7SK09YveHY2hwF6cGH9ihesGSEA4jdSCr+q/zQYlXj/usH6Qeddgq0aq/13LMcF82O7P+lH/TYdyR9cXFkpO1ehEERQLlEmO+jGHoDPtWT8Fju/PmTS56EafRF4G5rw==", ENDITEM, 
		"Name=__ASYNCPOST", "Value=true", ENDITEM, 
		LAST);

	web_custom_request("Home.aspx_3", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Home.aspx", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"Body=ctl00%24ScriptManager1=ctl00%24ScriptManager1%7Cctl00%24Timer1&__EVENTTARGET=ctl00%24Timer1&__EVENTARGUMENT=&__VIEWSTATE=%2FwEPDwULLTE5MjM3MTA3MDUPZBYCZg9kFgICAw9kFgICCQ8PFgIeBFRleHQFA0FteWRkZNcbrXssUatf8XeAYdwC3GJikOHP9foNrlBSKhg70%2FCf&__VIEWSTATEGENERATOR=9AF846BE&__EVENTVALIDATION=%2FwEdAAbGoIx1NUIs8myhD625%2BrjI3IoTh%2FglSZuXftLnCL75vaL7SK09YveHY2hwF6cGH9ihesGSEA4jdSCr%2Bq%2FzQYlXj%2FusH6Qeddgq0aq%2F13LMcF82O7P%2BlH%2FTYdyR9cXFkpO1ehEERQLlEmO%2BjGHoDPtWT8Fju%2FPmTS56EafRF4G5rw%3D%3D&"
		"__ASYNCPOST=true&", 
		LAST);
lr_end_transaction("iBank_NET_002_Login", LR_AUTO);
	
lr_start_transaction("iBank_NET_004_Portfolio");
	web_url("Portfolio.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Portfolio.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Home.aspx", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=BxlGf4AXK3gGaC0jrvd5liEMq6fFNPJ3lAAozgY-BC2tA_rtEqrQWJOpXbGAtfSKBDfd8tIecTBgGqpvwIfpvnh88vQq69CV4T0JmxG3J5A1&t=635823488460000000", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=Ew1Vj9TZRQHg_fldiHYtE6mwLj-pXP0wCnrM0WaP6zVMbo2TbcA64sjkws7qSfTQgCWO_PereysjcPxwWeEL8LGiHI9HEkx7WgjHohl0OpisuyPH0anmLl--DoX2HtsNRnfItAHgHQ7D0wr5C1fXXg2&t=36fde08a", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=-oxN7qCMtcOxub6C3XfChlqzy5SR5yfIn1euYjEdEWIfW4RkT5e5gEhxBO411Hlnn6GMcAfOf8wBYYjrLmQ_ArnAE4Mpx786ZiQ5dyfOxa7-k7hVwpTGTuzawe2gyyLJHuzyH_rgUWxzq-zF5xPPQ_hHt_s58IfTSJfXCcm8iariADirxzug86baSo4Ic1qi0&t=ffffffffcc58dd65", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=CvxhkvAH3cnFbtHtX1z1yh8gK-7VYUthonFxO6HhYQBfTOF406fRuhSWsFTfHH-jqGZydOg7kKV2Gp48sQUNTJxjCDYCSWcU-el4c_8_aovWRJ7aOjNjHIYkkpfQLyPFGkpcGs9F1j3MnB_VubVM4bZhzMYUOOXzmuA7b0vpVKGue4FLW8OQXsmZFqEboHrY0&t=ffffffffcc58dd65", ENDITEM, 
		"Url=../iBank_Investor_deploy/ScriptResource.axd?d=MJJDHH-k-sR8F2qWFBYVHZNNQOdSQCJ1SW_6aVCn_9d_h18l8m5OPd2pZapHaZXNBYlUBAZR60XhRrRAAe2vSX64Fov4hqIsnCfD7QY8QiU7iFxAjs3XNoiFuYgNI_o0RKX82B4QO8UW47Rv3sNuAWCSnQLWXNQAWI8npewxF8ht7Dv2_XlOfajf4BiMG-ra0&t=ffffffffcc58dd65", ENDITEM, 
		"Url=Images/up.JPG", ENDITEM, 
		LAST);

	web_submit_data("Portfolio.aspx_2", 
		"Action=http://10.10.3.155/iBank_investor_deploy/Portfolio.aspx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Portfolio.aspx", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ctl00$ScriptManager1", "Value=ctl00$ScriptManager1|ctl00$Timer1", ENDITEM, 
		"Name=__EVENTTARGET", "Value=ctl00$Timer1", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/"
		"wEPDwUKMTgwMzU5NDE4MQ9kFgJmD2QWAgIDD2QWBAIJDw8WAh4EVGV4dAUDQW15ZGQCDQ9kFgQCAQ8PFgIfAAUGNDUyMzUyZGQCCQ88KwARAwAPFgYeE0F1dG9HZW5lcmF0ZUNvbHVtbnNoHgtfIURhdGFCb3VuZGceC18hSXRlbUNvdW50AgRkARAWABYAFgAMFCsAABYCZg9kFgoCAQ9kFhZmDw8WAh8ABQNBWFBkZAIBDw8WAh8ABQYxMjQuMDBkZAICDw8WAh8ABQU4Ny4yMmRkAgMPDxYCHwAFCSQxLDY0MC45M2RkAgQPDxYCHwAFBzE3MzYuOTNkZAIFDw8WAh8ABQokMTAsODE1LjI4ZGQCBg8PFgIfAAULJDIwMyw0NzUuMzBkZAIHDw8WAh8ABQY2MDUuMDBkZAIIDw8WAh8ABQskMTkyLDY2MC4wMGRkAgkPD2QWAh4Hb25jbGljawVHamF2YXNjcmlwdDpfX2RvUG9zdEJ"
		"hY2soJ2N0bDAwJE1haW5Db250ZW50JEdyaWRWaWV3MSRjdGwwMiRjdGwwMScsJzEwJykWAmYPDxYCHwAFA0J1eWRkAgoPD2QWAh4Fc3R5bGUFNmN1cnNvcjpwb2ludGVyO2N1cnNvcjpoYW5kO2N1cnNvcjpwb2ludGVyO2N1cnNvcjpoYW5kOxYCZg8PFgIfAAUEU2VsbGRkAgIPZBYWZg8PFgIfAAUDSUJNZGQCAQ8PFgIfAAUFODYuMDBkZAICDw8WAh8ABQMxNzlkZAIDDw8WAh8ABQkkMSw3MTYuOThkZAIEDw8WAh8ABQY4MzcuMDZkZAIFDw8WAh8ABQokMTUsMzk0LjAwZGQCBg8PFgIfAAULJDE0Nyw2NjAuMzBkZAIHDw8WAh8ABQUtMjMwMGRkAggPDxYCHwAFCyQxMzIsMjY2LjMwZGQCCQ8PZBYCHwQFR2phdmFzY3JpcHQ6X19kb1Bvc3RCYWNrKCdjdGwwMCRNYWluQ"
		"29udGVudCRHcmlkVmlldzEkY3RsMDMkY3RsMDEnLCcxMCcpFgJmDw8WAh8ABQNCdXlkZAIKDw9kFgIfBQU2Y3Vyc29yOnBvaW50ZXI7Y3Vyc29yOmhhbmQ7Y3Vyc29yOnBvaW50ZXI7Y3Vyc29yOmhhbmQ7FgJmDw8WAh8ABQRTZWxsZGQCAw9kFhZmDw8WAh8ABQRNU0ZUZGQCAQ8PFgIfAAUFNjkuMDBkZAICDw8WAh8ABQU0Mi45MGRkAgMPDxYCHwAFCSQxLDU4Mi40MmRkAgQPDxYCHwAFBzM2NjMuMTlkZAIFDw8WAh8ABQkkMiw5NjAuMTBkZAIGDw8WAh8ABQskMTA5LDE4Ny4wMGRkAgcPDxYCHwAFAzEwMGRkAggPDxYCHwAFCyQxMDYsMjI2LjkwZGQCCQ8PZBYCHwQFR2phdmFzY3JpcHQ6X19kb1Bvc3RCYWNrKCdjdGwwMCRNYWluQ29udGVudCRHcmlkVmlldzEkY3R"
		"sMDQkY3RsMDEnLCcxMCcpFgJmDw8WAh8ABQNCdXlkZAIKDw9kFgIfBQU2Y3Vyc29yOnBvaW50ZXI7Y3Vyc29yOmhhbmQ7Y3Vyc29yOnBvaW50ZXI7Y3Vyc29yOmhhbmQ7FgJmDw8WAh8ABQRTZWxsZGQCBA9kFhZmDw8WAh8ABQNIUFFkZAIBDw8WAh8ABQUxMC4wMGRkAgIPDxYCHwAFBTM0LjMxZGQCAw8PFgIfAAUJJDEsNTY5LjY4ZGQCBA8PFgIfAAUHNDUxNS4zNWRkAgUPDxYCHwAFByQzNDMuMTBkZAIGDw8WAh8ABQokMTUsNjk2LjgwZGQCBw8PFgIfAAUGMzUzLjIwZGQCCA8PFgIfAAUKJDE1LDM1My43MGRkAgkPD2QWAh8EBUdqYXZhc2NyaXB0Ol9fZG9Qb3N0QmFjaygnY3RsMDAkTWFpbkNvbnRlbnQkR3JpZFZpZXcxJGN0bDA1JGN0bDAxJywnMTAnKRYCZg8PF"
		"gIfAAUDQnV5ZGQCCg8PZBYCHwUFNmN1cnNvcjpwb2ludGVyO2N1cnNvcjpoYW5kO2N1cnNvcjpwb2ludGVyO2N1cnNvcjpoYW5kOxYCZg8PFgIfAAUEU2VsbGRkAgUPDxYCHgdWaXNpYmxlaGRkGAEFG2N0bDAwJE1haW5Db250ZW50JEdyaWRWaWV3MQ88KwAMAQgCAWSglGknrSyJSiCvy+U4L9B2AB1T/nmXA3A1g9q/4D3/3Q==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=39F23C40", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAxyYZGN7MeWuFAai5ophcARO3eWIHg1Y4pfIpPDykmsg/5kozZJSfVS+BvdIWYBzqgJ+eNQxp4kE9l6kq4vJ8gYjbMFrxkD+8G7/SY0tmYyQXxipb6h6JK8BRguhf3iZdkb+rmRrSQvwQJiED9C0IYwQ60pfM/pdqv45o/wCZLYTfgEry2Uz3QcseE7Ps5AB7xlWBeSO2wgdteYyUsJFAXAfh/mM0+v+Zcjs71SlmeK+PvhNBQhdgEtRV+CBqP2BwuUIW72y7LWiw+QmU+T0zvzI+d+c9nuqdkLzDHaXQeSbw==", ENDITEM, 
		"Name=__ASYNCPOST", "Value=true", ENDITEM, 
		LAST);
	lr_end_transaction("iBank_NET_004_Portfolio", LR_AUTO);

lr_start_transaction("iBank_NET_999_Logout");

	web_url("Logout.aspx", 
		"URL=http://10.10.3.155/iBank_investor_deploy/Logout.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://10.10.3.155/iBank_investor_deploy/Trading.aspx", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=BxlGf4AXK3gGaC0jrvd5liEMq6fFNPJ3lAAozgY-BC2tA_rtEqrQWJOpXbGAtfSKBDfd8tIecTBgGqpvwIfpvnh88vQq69CV4T0JmxG3J5A1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=../iBank_Investor_deploy/WebResource.axd?d=-zB6828wYI1dChaSKumS2PFmSzA2xP9PGL0_G1OqBM09305dfJsdqmnNdvkvc1Hj282OBi8bxb1ky1nWo-8qn91mS4-qmQWQgi3QLCk7RLw1&t=635823488460000000", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		"Url=Images/tradetips.JPG", "Referer=http://10.10.3.155/iBank_investor_deploy/Login.aspx", ENDITEM, 
		LAST);
lr_end_transaction("iBank_NET_999_Logout", LR_AUTO);

	return 0;
}